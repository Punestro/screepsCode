var roleLogistic = {

    /** @param {Creep} creep **/
    run: function(creep) {
        
        if(creep.memory.supplying && creep.carry.energy == 0) {
            creep.memory.supplying = false;
            creep.say('fetching');
        }
        if(!creep.memory.supplying && creep.carry.energy == creep.carryCapacity) {
            creep.memory.supplying = true;
            creep.say('supplying');
        }
        
       // if (creep.memory.supplying) {
       //     var stores = creep.room.find(FIND_STRUCTURES, {
       //         filter: (structure) =&gt; {
        //            return (structure.structureType == STRUCTURE_STORAGE) && (structure.store[RESOURCE_ENERGY] &lt; structure.storeCapacity);
        //        }
         //   });
        //    if (stores && stores.length &gt; 0) {
        //        if(creep.transfer(stores[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
        //            creep.moveTo(stores[0]);
        //        }
         //   }
        //}        
        if (creep.memory.supplying) {
            var targets = creep.room.find(FIND_STRUCTURES, {
                    filter: (structure) => {
                        return (structure.structureType == STRUCTURE_EXTENSION || structure.structureType == STRUCTURE_SPAWN) &&
                            structure.store.getFreeCapacity(RESOURCE_ENERGY) > 0;
                     }
            });
            if (targets && targets.length > 0) {
                if(creep.transfer(targets[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(targets[0]);
                }
            }
        } else {
            var containers = creep.room.find(FIND_STRUCTURES, {
                filter: (structure) =&gt; {
                    return (structure.structureType == STRUCTURE_CONTAINER) && (structure.store[RESOURCE_ENERGY] &gt; 0);
                }
            });
            var source = creep.pos.findClosestByPath(containers);
            if (source) {
                if(creep.withdraw(source, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(source);
                }
            }
        }
    }
};

module.exports = roleLogistic;
