var roleHarvester = require('role.harvester');
var roleBuilder = require('role.builder');
var roleUpgrader = require('role.upgrader');
var roleSupport = require('role.support');
var roleLink = require('role.link');


// Adjust Source values
Memory.sourceMainframe  = '843dc0e2e35fa0352227719b';
Memory.sourceController = 'b81ec224da4758aab7a75822';

// Builds for Creeps
var aBuild = [WORK,CARRY,MOVE]; var bBuild = [WORK,WORK,CARRY,CARRY,MOVE,MOVE]; var cBuild = [WORK,WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,CARRY,CARRY,MOVE];

// Adjust Creep values
var numH = 2; var bldH = bBuild;  Memory.sourceH = Memory.sourceMainframe  // Harvester
var numU = 1; var bldU = bBuild;  Memory.sourceU = Memory.sourceController // Upgrader
var numB = 0; var bldB = aBuild;  Memory.sourceB = Memory.sourceMainframe  // Builder
var numS = 1; var bldS = cBuild;  Memory.sourceS = Memory.sourceMainframe // Support


var idTower=''

module.exports.loop = function () {

// Harvesters
    
    var harvesters = _.filter(Game.creeps, (creep) => creep.memory.role == 'harvester');
    if(harvesters.length < numH) {
    var newName = 'Harvester' + Game.time;
    console.log('Spawning new harvester: ' + newName);
    Game.spawns['Mainframe1'].spawnCreep(bldH, newName, 
        {memory: {role: 'harvester'}});        
}

// Upgraders
    var upgraders = _.filter(Game.creeps, (creep) => creep.memory.role == 'upgrader');
    
    if(upgraders.length < numU && harvesters.length > 1) {
    var newName = 'Upgrader' + Game.time;
    console.log('Spawning new upgrader: ' + newName);
    Game.spawns['Mainframe1'].spawnCreep(bldU, newName, 
        {memory: {role: 'upgrader'}});        
}

// Builders
    var builders = _.filter(Game.creeps, (creep) => creep.memory.role == 'builder');
    
    if(builders.length < numB && harvesters.length > 1) {
    var newName = 'Builder' + Game.time;
    console.log('Spawning new builder: ' + newName);
    Game.spawns['Mainframe1'].spawnCreep(bldB, newName, 
        {memory: {role: 'builder'}});        
}

// Support
    var supports = _.filter(Game.creeps, (creep) => creep.memory.role == 'support');

    if(supports.length < numS && harvesters.length > 1) {
    var newName = 'Support' + Game.time;
    console.log('Spawning new harvester: ' + newName);
    Game.spawns['Mainframe1'].spawnCreep(bldS, newName, 
        {memory: {role: 'support'}});        
}

// Link
    var links = _.filter(Game.creeps, (creep) => creep.memory.role == 'link');
    
    if(links.length < numS && harvesters.length > 1) {
    var newName = 'link' + Game.time;
    console.log('Spawning new link: ' + newName);
    Game.spawns['Mainframe1'].spawnCreep(bldS, newName, 
        {memory: {role: 'link'}});        
}


// Tower   
    var tower = Game.getObjectById(idTower);
    if(tower) {
        var closestDamagedStructure = tower.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (structure) => structure.hits < 1000 || 
                (structure.hits > 100000 && structure.hits < 150000) ||
                ((structure.structureType == STRUCTURE_WALL || structure.structureType == STRUCTURE_RAMPART) && structure.hits < 5000)
        });
        if(closestDamagedStructure) {
            tower.repair(closestDamagedStructure);
            

        }

        var closestHostile = tower.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
        if(closestHostile) {
            tower.attack(closestHostile);
        }
    }


// Links

var linkMainframe = Game.getObjectById('64a54d09c856b4b5a5650285');
var linkController = Game.getObjectById('594089c8109b834401c3859f');
linkMainframe.transferEnergy(linkController, 100);


// AutoSpawn

if(Game.spawns['Mainframe1'].spawning) { 
    var spawningCreep = Game.creeps[Game.spawns['Mainframe1'].spawning.name];
    Game.spawns['Mainframe1'].room.visual.text(
        '🛠️' + spawningCreep.memory.role,
        Game.spawns['Mainframe1'].pos.x + 1, 
        Game.spawns['Mainframe1'].pos.y, 
        {align: 'left', opacity: 0.8});
}

// Clear creep memory

for(var name in Memory.creeps) {
    if(!Game.creeps[name]) {
        delete Memory.creeps[name];
        console.log('Clearing non-existing creep memory:', name);
    }
}

// Roles run

for(var name in Game.creeps) {
    var creep = Game.creeps[name];
    if(creep.memory.role == 'harvester') {
        roleHarvester.run(creep);
    }
    if(creep.memory.role == 'builder') {
        roleBuilder.run(creep);
    }
     if(creep.memory.role == 'upgrader') {
        roleUpgrader.run(creep);
    }
     if(creep.memory.role == 'support') {
        roleSupport.run(creep);
    }
     if(creep.memory.role == 'link') {
        roleLink.run(creep);
    }

}
}
