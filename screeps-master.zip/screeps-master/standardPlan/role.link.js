var roleLink = {

run: function(creep) {

    if(creep.memory.upgrading && creep.store[RESOURCE_ENERGY] == 0) {
        creep.memory.upgrading = false;
        creep.say('🔄 harvest');
    }
    if(!creep.memory.upgrading && creep.store.getFreeCapacity() == 0) {
        creep.memory.upgrading = true;
        creep.say('⚡ upgrade');
    }

    if(creep.memory.upgrading) {
        if(creep.upgradeController(creep.room.controller) == ERR_NOT_IN_RANGE) {
            creep.moveTo(creep.room.controller, {visualizePathStyle: {stroke: '#c2d9ff'}});
        }
    }
    else {
            var links = creep.room.find(FIND_STRUCTURES, {
                filter: (structure) => {
                    return (structure.structureType == STRUCTURE_LINK) && (structure.store[RESOURCE_ENERGY] > 0);
                }
            });
            var source = creep.pos.findClosestByRange (links);
            if (source) {
                if(creep.withdraw(source, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(source), {visualizePathStyle: {stroke: '#c2d9ff'}};
                }
            }

    }
}
};

module.exports = roleLink;



//            var link = Game.getObjectById('594089c8109b834401c3859f');        
//            if(creep.moveTo(link) == ERR_NOT_IN_RANGE) {
//            creep.moveTo(link), {visualizePathStyle: {stroke: '#c2d9ff'}};
//            creep.transfer(link, 50)
//        }
//    else {
//        var stuffsources = Game.getObjectById(Memory.sourceU);
//        if(creep.harvest(stuffsources) == ERR_NOT_IN_RANGE) {
//            creep.moveTo(stuffsources), {visualizePathStyle: {stroke: '#c2d9ff'}};
//        }

