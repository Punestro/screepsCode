--Ranger Code
var rangeSoldier = {

run: function(creep) {
    
    creep.moveTo(Game.flags.guardShack);
    var closestHostile = creep.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
    if(closestHostile) {
        creep.moveTo(closestHostile);
        creep.rangedAttack(closestHostile);
    }
    
     
    }
    
    
};
module.exports = rolerangesoldier;
--Melee Code
var roleSoldier = {

run: function(creep) {
    
    creep.moveTo(Game.flags.rally);
    var closestHostile = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES);
    if(closestHostile) {
        creep.moveTo(closestHostile);
        creep.attack(closestHostile);
    }
    
     
    }
    
    
};
module.exports = roleSoldier;
--Healer Code
var roleHealer = {
    
run: function(creep) {

creep.moveTo(Game.flags.guardShack);

if(creep) { var closestDamagedAlly = creep.pos.findClosestByRange(FIND_CREEPS,
{ filter: (creeps) => creep.hits < creep.hitsMax }); 
if(closestDamagedAlly) { creep.heal(closestDamagedAlly); }

    var closestHostile = creep.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
    if(closestHostile) {
        creep.attack(closestHostile);
    }
}

}
};
module.exports = roleHealer;
--Claimer Code

var roleClaimer = {

/** @param {Creep} creep **/ run: function(creep) {

creep.moveTo(Game.flags.control);
creep.moveTo(creep.room.controller);
creep.claim(creep.room.controller);


       }
};

module.exports = roleClaimer;

