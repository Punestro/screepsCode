https://screeps.com/forum/topic/2364/harvesting-from-multiple-sources-within-a-room/3

var listSources = creep.room.find(FIND_SOURCES)
Than you can save this id on the creep memory:

creep1.memory.sourceID = listSources[0].id;
creep2.memory.sourceID = listSources[1].id;
After it your harvester function can look like this:

run: function(creep) {
    if(creep.carry.energy < creep.carryCapacity) {
        var source = Game.getObjetcByID(creep.memory.sourceID)
        if(creep.harvest(source) == ERR_NOT_IN_RANGE) {
            creep.moveTo(source, {visualizePathStyle: {stroke: '#ffaa00'}});
        }
    }
