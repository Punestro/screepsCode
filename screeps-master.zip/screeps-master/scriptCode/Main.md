Basic:

Builder Spawwn Code:
Game.spawns['SpawnName'].spawnCreep( [WORK, CARRY, MOVE], 'HarvesterName' );

A bit more advanced:

Spawn a builder:
Game.spawns['SpawnName'].spawnCreep( [WORK, CARRY, MOVE], 'BuilderName',
    { memory: { role: 'builder' } } );
Spawn an Upgrader:
Game.spawns['SpawnName'].spawnCreep( [WORK, CARRY, MOVE], 'UpgraderName',
    { memory: { role: 'upgrader' } } );
Spawn a Harvester:
Game.spawns['SpawnName'].spawnCreep( [WORK, CARRY, MOVE], 'HarvesterName',
    { memory: { role: 'harvester' } } );

How to build a defence tower:
Game.spawns['SpawnName'].room.createConstructionSite( coordinates, STRUCTURE_TOWER );
Game.spawns['SpawnName'].room.createConstructionSite( 4, 14 STRUCTURE_EXTENSION );

Activate safe mode with code:
Game.spawns['SpawnName'].room.controller.activateSafeMode();
