[int]$mov = Read-Host 'Move '
[int]$wrk = Read-Host 'Work '
[int]$cry = Read-Host 'Carry '
[int]$atk = Read-Host 'Melee Attack '
[int]$rng = Read-Host 'Ranged Attack '
[int]$hea = Read-Host 'Heal '
[int]$tuf = Read-Host 'Tough '
[int]$clm = Read-Host 'Claim '

$energy = ($mov * 50) + ($wrk * 100) + ($cry * 50) + ($atk * 80) + ($rng * 150) + ($hea * 250) + ($tuf * 10) + ($clm * 600)
cls
Write-Host "Total Energy Required: $energy"
