var roleHarvester = require('role.harvester');
var roleBuilder = require('role.builder');
var roleUpgrader = require('role.upgrader');
var roleSupport = require('role.support');

// Adjust Source values
Memory.sourceMainframe  = '8e7401fbdedcf2f0d780d5a0';
Memory.sourceController = 'e528e946ca42e229b8cb4423';

// Builds for Creeps
var aBuild = [WORK,CARRY,MOVE]; var bBuild = [WORK,WORK,CARRY,CARRY,MOVE,MOVE]; var cBuild = [WORK,CARRY,CARRY,MOVE];

// Adjust Creep values
var numH = 3; var bldH = aBuild;  Memory.sourceH = Memory.sourceMainframe  // Harvester
var numU = 3; var bldU = aBuild;  Memory.sourceU = Memory.sourceController // Upgrader
var numB = 2; var bldB = aBuild;  Memory.sourceB = Memory.sourceMainframe  // Builder
var numS = 1; var bldS = aBuild;  Memory.sourceS = Memory.sourceController // Support


var idTower='0737285a6051f7b5a31db0e8'

module.exports.loop = function () {
    
    var harvesters = _.filter(Game.creeps, (creep) => creep.memory.role == 'harvester');
    var builders = _.filter(Game.creeps, (creep) => creep.memory.role == 'builder');
    var upgraders = _.filter(Game.creeps, (creep) => creep.memory.role == 'upgrader');
    var supports = _.filter(Game.creeps, (creep) => creep.memory.role == 'support');
    
    var tower = Game.getObjectById(idTower);
    if(tower) {
        var closestDamagedStructure = tower.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (structure) => structure.hits < 1000 || 
                (structure.hits > 100000 && structure.hits < 150000) ||
                ((structure.structureType == STRUCTURE_WALL || structure.structureType == STRUCTURE_RAMPART) && structure.hits < 5000)
        });
        if(closestDamagedStructure) {
            tower.repair(closestDamagedStructure);
            

        }

        var closestHostile = tower.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
        if(closestHostile) {
            tower.attack(closestHostile);
        }
    }

if(harvesters.length < numH) {
    var newName = 'Harvester' + Game.time;
    console.log('Spawning new harvester: ' + newName);
    Game.spawns['Mainframe1'].spawnCreep(bldH, newName, 
        {memory: {role: 'harvester'}});        
}

if(Game.spawns['Mainframe1'].spawning) { 
    var spawningCreep = Game.creeps[Game.spawns['Mainframe1'].spawning.name];
    Game.spawns['Mainframe1'].room.visual.text(
        '🛠️' + spawningCreep.memory.role,
        Game.spawns['Mainframe1'].pos.x + 1, 
        Game.spawns['Mainframe1'].pos.y, 
        {align: 'left', opacity: 0.8});
}
if(builders.length < numB) {
    var newName = 'Builder' + Game.time;
    console.log('Spawning new builder: ' + newName);
    Game.spawns['Mainframe1'].spawnCreep(bldB, newName, 
        {memory: {role: 'builder'}});        
}

if(Game.spawns['Mainframe1'].spawning) { 
    var spawningCreep = Game.creeps[Game.spawns['Mainframe1'].spawning.name];
    Game.spawns['Mainframe1'].room.visual.text(
        '🛠️' + spawningCreep.memory.role,
        Game.spawns['Mainframe1'].pos.x + 1, 
        Game.spawns['Mainframe1'].pos.y, 
        {align: 'left', opacity: 0.8});
}
if(upgraders.length < numU) {
    var newName = 'Upgrader' + Game.time;
    console.log('Spawning new upgrader: ' + newName);
    Game.spawns['Mainframe1'].spawnCreep(bldU, newName, 
        {memory: {role: 'upgrader'}});        
}

if(Game.spawns['Mainframe1'].spawning) { 
    var spawningCreep = Game.creeps[Game.spawns['Mainframe1'].spawning.name];
    Game.spawns['Mainframe1'].room.visual.text(
        '🛠️' + spawningCreep.memory.role,
        Game.spawns['Mainframe1'].pos.x + 1, 
        Game.spawns['Mainframe1'].pos.y, 
        {align: 'left', opacity: 0.8});
}

if(supports.length < numS) {
    var newName = 'Support' + Game.time;
    console.log('Spawning new harvester: ' + newName);
    Game.spawns['Mainframe1'].spawnCreep(bldS, newName, 
        {memory: {role: 'support'}});        
}

if(Game.spawns['Mainframe1'].spawning) { 
    var spawningCreep = Game.creeps[Game.spawns['Mainframe1'].spawning.name];
    Game.spawns['Mainframe1'].room.visual.text(
        '🛠️' + spawningCreep.memory.role,
        Game.spawns['Mainframe1'].pos.x + 1, 
        Game.spawns['Mainframe1'].pos.y, 
        {align: 'left', opacity: 0.8});
}

for(var name in Memory.creeps) {
    if(!Game.creeps[name]) {
        delete Memory.creeps[name];
        console.log('Clearing non-existing creep memory:', name);
    }
}

for(var name in Game.creeps) {
    var creep = Game.creeps[name];
    if(creep.memory.role == 'harvester') {
        roleHarvester.run(creep);
    }
    if(creep.memory.role == 'builder') {
        roleBuilder.run(creep);
    }
     if(creep.memory.role == 'upgrader') {
        roleUpgrader.run(creep);
    }
     if(creep.memory.role == 'support') {
        roleSupport.run(creep);
    }

}
}
