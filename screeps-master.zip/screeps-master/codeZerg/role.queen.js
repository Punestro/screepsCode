var roleQueen = {

    run: function(creep) {
        
        if (creep.memory.pull && creep.carry.energy == 0) {
            creep.memory.pull = false;
            creep.say('Pull');
        }
        if (!creep.memory.pull && creep.carry.energy == creep.carryCapacity) {
            creep.memory.pull = true;
            creep.say('Push');
        }
        
        if (creep.memory.pull) {
            var stores = creep.room.find(FIND_STRUCTURES, {
                filter: (structure) => {
                    return (structure.structureType == STRUCTURE_EXTENSION || 
                            structure.structureType == STRUCTURE_SPAWN) && (structure.store.getFreeCapacity(RESOURCE_ENERGY) > 0);
                }
            });
            if (stores && stores.length > 0) {
                if(creep.transfer(stores[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(stores[0], {visualizePathStyle: {stroke: '#ecc9ff'}});
                }
            }
        } 
        
        else {
            var containers = creep.room.find(FIND_STRUCTURES, {
                filter: (structure) => {
                    return (structure.structureType == STRUCTURE_CONTAINER) && (structure.store[RESOURCE_ENERGY] > 0);
                }
            });
            var source = creep.pos.findClosestByPath(containers);
            if (source) {
                if(creep.withdraw(source, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(source), {visualizePathStyle: {stroke: '#ecc9ff'}};
                }
            }
        }
    }
};

module.exports = roleQueen;
