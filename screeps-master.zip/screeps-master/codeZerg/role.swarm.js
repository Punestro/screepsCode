var roleSwarm = {

    run: function(creep) {
        
        if (creep.memory.pull && creep.carry.energy == 0) {
            creep.memory.pull = false;
            creep.say('Pull');
        }
        if (!creep.memory.pull && creep.carry.energy == creep.carryCapacity) {
            creep.memory.pull = true;
            creep.say('Push');
        }
        
        if (creep.memory.pull) {
            var targets = creep.room.find(FIND_CONSTRUCTION_SITES);
                if(targets.length) {
                    if(creep.build(targets[0]) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(targets[0], {visualizePathStyle: {stroke: '#b3f9c6'}});
                    }
                }
        }
        
        else {
            var sources = Game.getObjectById(Memory.sourceB);
                creep.moveTo(sources), {visualizePathStyle: {stroke: '#b3f9c6'}};
                creep.harvest(sources);
        }
    }
};

module.exports = roleSwarm;
