var roleDrone = require('role.drone');
var roleZerg = require('role.zerg');
var roleQueen = require('role.queen');
var roleSwarm = require('role.swarm');
var roleLocust = require('role.locust');


// Adjust Source values
Memory.sourceMainframe  = '5bbcac919099fc012e635bb8';
Memory.sourceController = '5bbcac919099fc012e635bb6';

// Builds for Creeps
var aBuild = [WORK,CARRY,MOVE];                             // Basic / Locust
var bBuild = [WORK,WORK,CARRY,CARRY,MOVE,MOVE];             // Zergs / Drones
var qBuild = [CARRY,CARRY,MOVE,MOVE];                       // Queen
var cBuild = [CARRY,CARRY,MOVE,MOVE,MOVE,MOVE];             // Custom

// Adjust Creep values
var numD = 3; var bldD = bBuild;  Memory.sourceD = Memory.sourceMainframe   // Harvester / Drone
var numZ = 3; var bldZ = bBuild;  Memory.sourceZ = Memory.sourceMainframe   // Upgrader / Zerg
var numQ = 1; var bldQ = qBuild;  Memory.sourceQ = Memory.sourceMainframe   // Logistic / Queen
var numW = 1; var bldW = aBuild;  Memory.sourceW = Memory.sourceController  // Builder / Swarm
var numL = 1; var bldL = aBuild;  Memory.sourceL = Memory.sourceController  // Support / Locust

var idTower=''
var idspawn='Hive'

module.exports.loop = function () {

// Harvester/Drone
    var drone = _.filter(Game.creeps, (creep) => creep.memory.role == 'drone');
    if(drone.length < numD) {
    var newName = 'Drone' + Game.time;
    console.log('Spawning new drone: ' + newName);
    Game.spawns['Mainframe1'].spawnCreep(bldD, newName, 
        {memory: {role: 'drone'}});        
    }

// Upgrader/Zerg
    var zerg = _.filter(Game.creeps, (creep) => creep.memory.role == 'zerg');
    if(zerg.length < numZ && drone.length > 1) {
    var newName = 'Zerg' + Game.time;
    console.log('Spawning new zerg: ' + newName);
    Game.spawns['Mainframe1'].spawnCreep(bldZ, newName, 
        {memory: {role: 'zerg'}});        
    }

// Builders/Swarm
    var swarm = _.filter(Game.creeps, (creep) => creep.memory.role == 'swarm');
    if(swarm.length < numW && drone.length > 1) {
    var newName = 'Swarm' + Game.time;
    console.log('Spawning new swarm: ' + newName);
    Game.spawns['Mainframe1'].spawnCreep(bldW, newName, 
        {memory: {role: 'swarm'}});        
    }

// Support/Locust
    var locust = _.filter(Game.creeps, (creep) => creep.memory.role == 'locust');
    if(locust.length < numL && drone.length > 1) {
    var newName = 'Locust' + Game.time;
    console.log('Spawning new support: ' + newName);
    Game.spawns['Mainframe1'].spawnCreep(bldL, newName, 
        {memory: {role: 'locust'}});        
    }

// Queen
    var queen = _.filter(Game.creeps, (creep) => creep.memory.role == 'queen');
    if(queen.length < numQ && drone.length > 1) {
    var newName = 'Queen' + Game.time;
    console.log('Spawning new queen: ' + newName);
    Game.spawns['Mainframe1'].spawnCreep(bldQ, newName, 
        {memory: {role: 'queen'}});        
    }

// Tower   
    var spire = Game.getObjectById(idSpire);
        if(spire) { 
            var closestDamagedStructure = spire.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (structure) => 
                ((structure.structureType == STRUCTURE_WALL || structure.structureType == STRUCTURE_RAMPART) && structure.hits < 2000) ||
                ((structure.structureType == STRUCTURE_ROAD) && structure.hits < 1000) ||
                ((structure.structureType == STRUCTURE_CONTAINER) && structure.hits < 10000)
            });
        
            if(closestDamagedStructure) {
            spire.repair(closestDamagedStructure);
            };
  
            var closestHostile = spire.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
            if(closestHostile) {
                spire.attack(closestHostile);
            }
        }

// AutoSpawn
    if(Game.spawns['Mainframe1'].spawning) { 
        var spawningCreep = Game.creeps[Game.spawns['Mainframe1'].spawning.name];
        Game.spawns['Mainframe1'].room.visual.text(
            '🛠️' + spawningCreep.memory.role,
            Game.spawns['Mainframe1'].pos.x + 1, 
            Game.spawns['Mainframe1'].pos.y, 
            {align: 'left', opacity: 0.8});
    }

// Clear creep memory
    for(var name in Memory.creeps) {
        if(!Game.creeps[name]) {
            delete Memory.creeps[name];
            console.log('Clearing non-existing creep memory:', name);
        }
    }

// Roles run
    for(var name in Game.creeps) {
        var creep = Game.creeps[name];
        if(creep.memory.role == 'drone') {
            roleDrone.run(creep);
        }
         if(creep.memory.role == 'zerg') {
            roleZerg.run(creep);
        }
         if(creep.memory.role == 'queen') {
            roleQueen.run(creep);
        }
            if(creep.memory.role == 'swarm') {
            roleSwarm.run(creep);
        }
         if(creep.memory.role == 'locust') {
            roleLocust.run(creep);
        }
    }
}
