var roleLocust = {

    run: function(creep) {
        
        if (creep.memory.pull && creep.carry.energy == 0) {
            creep.memory.pull = false;
            creep.say('Pull');
        }
        if (!creep.memory.pull && creep.carry.energy == creep.carryCapacity) {
            creep.memory.pull = true;
            creep.say('Push');
        }
        
        if (creep.memory.pull) {
            var targets = creep.room.find(FIND_STRUCTURES, {
                filter: (structure) => {
                    return (/*structure.structureType == STRUCTURE_EXTENSION ||
                            structure.structureType == STRUCTURE_SPAWN ||*/
                            structure.structureType == STRUCTURE_TOWER
                            //structure.structureType == STRUCTURE_CONTAINER ||
                            //structure.structureType == STRUCTURE_ROAD
                            )
                }
            });
            if(targets.length > 0) {
                if(creep.transfer(targets[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(targets[0], {visualizePathStyle: {stroke: '#ffffff'}});
                }
            }
        }
        
        else {
            var sources = Game.getObjectById(Memory.sourceS);
            if(creep.harvest(sources) == ERR_NOT_IN_RANGE) {
                creep.moveTo(sources), {visualizePathStyle: {stroke: '#f8ffab'}};
            }
        }
    }
};

module.exports = roleLocust;
