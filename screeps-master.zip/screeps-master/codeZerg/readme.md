
## Overview
This is to introduce a push pull concept to all jobs in Screeps

## Level 1
Use the PlanStandard to quickly get up and going with minimal effort

## Level 2/3
Use codeZerg to start using a common container 

## Basic Sections

### Gathering from Sources
```
var sources = creep.room.find(FIND_SOURCES);
if(creep.harvest(sources[0]) == ERR_NOT_IN_RANGE) {
    creep.moveTo(sources[0], {visualizePathStyle: {stroke: '#ffaa00'}});
}
```

### Find Structures that need Energy
```
var stores = creep.room.find(FIND_STRUCTURES, {
    filter: (structure) => {
        return (structure.structureType == STRUCTURE_EXTENSION || 
            structure.structureType == STRUCTURE_SPAWN) && (structure.store.getFreeCapacity(RESOURCE_ENERGY) > 0);
    }
});
```
