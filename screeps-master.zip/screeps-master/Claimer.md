var roleClaimer = {

/** @param {Creep} creep **/
run: function(creep) {

    creep.moveTo(Game.flags.control);
    creep.moveTo( {visualizePathStyle: {stroke: '#ffaa00'}});
   
    
           }
};

module.exports = roleBuilder;
