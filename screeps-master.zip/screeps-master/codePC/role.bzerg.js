var roleBZerg = {

    run: function(creep) {
        
        if (creep.memory.pull && creep.carry.energy == 0) {
            creep.memory.pull = false;
            creep.say('🦊');
        }
        if (!creep.memory.pull && creep.carry.energy == creep.carryCapacity) {
            creep.memory.pull = true;
            creep.say('🦊');
        }
        
        if (creep.memory.pull) {
            if (creep.upgradeController(creep.room.controller) == ERR_NOT_IN_RANGE) {
                creep.moveTo(creep.room.controller, {visualizePathStyle: {stroke: '#C1FFBF'}});
            }
        }
        
        else {
            var containers = creep.room.find(FIND_STRUCTURES, {
                filter: (structure) => {
                    return (structure.structureType == STRUCTURE_LINK) && (structure.store[RESOURCE_ENERGY] > 0);
                }
            });
            var source = creep.pos.findClosestByPath(containers);
            if (source) {
                if(creep.withdraw(source, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(source), {visualizePathStyle: {stroke: '#C1FFBF'}};
                }
            }
        }
    }
};

module.exports = roleBZerg;
