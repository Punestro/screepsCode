var roleRoach = {

run: function(creep) {
    creep.moveTo(Game.flags.rally);
   // var closestHostile = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES);
    var closestHostile = creep.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
    if(closestHostile) {
        creep.moveTo(closestHostile);
        creep.attack(closestHostile);
    }
    
     
    }
    
    
};
module.exports = roleRoach;
