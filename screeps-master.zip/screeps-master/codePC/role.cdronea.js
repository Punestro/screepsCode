var roleCDroneB = {

    run: function(creep) {
        if (creep.memory.pull && creep.carry.energy == 0) {
            creep.memory.pull = false;
            creep.say('🐹');
        }
        if (!creep.memory.pull && creep.carry.energy == creep.carryCapacity) {
            creep.memory.pull = true;
            creep.say('🐹');
        }
        
        if (creep.memory.pull) {
            creep.moveTo(Game.flags.DropOff2), {visualizePathStyle: {stroke: '#DCBFF5'}};
            var containers = Game.getObjectById('5f0810b540c897346646b1a9');
            
            if (containers) {
                if(creep.transfer(containers, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(containers), {visualizePathStyle: {stroke: '#DCBFF5'}};
                }
            }
        }
        
        else {
            var sources = Game.getObjectById('5bbcac839099fc012e635982');
                creep.moveTo(Game.flags.CMainB), {visualizePathStyle: {stroke: '#DCBFF5'}};
                creep.harvest(sources);
        }
    }
};

module.exports = roleCDroneB;
