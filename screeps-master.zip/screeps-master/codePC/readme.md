# PowerCore Code

## Overview
To highlight some of the reasons for the code

## Job Descriptions
* 🐰 **Carrier** - Pick up left over resources on the ground
* 🐹 **Drone** - Harvest Energy from sources
* 🐼 **Locust** - Support the spires
* 🦝 **Lurker** - Support the upgraders
* 🦁 **Queen** - Keep the Extensions and Source full of energy
* 🐻 **Runner** - Gather resources from containers and carry to Storage
* 🦊 **Zerg** - Upgrade the Controller


