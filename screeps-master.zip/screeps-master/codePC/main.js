// Associated Files - Mainframe
var roleAQueen      = require('role.aqueen'); 
var roleARunner     = require('role.arunner');
var roleADroneA     = require('role.adronea');
var roleADroneB     = require('role.adroneb');
var roleAZerg       = require('role.azerg'); 
var roleACarrier    = require('role.acarrier');
var roleALocust     = require('role.alocust'); 
var roleALurker     = require('role.alurker');
var roleASwarm      = require('role.aswarm');
var roleAMiner      = require('role.aminer');

// Associated Files - Mainframe2
var roleBQueen      = require('role.bqueen'); 
var roleBRunner     = require('role.brunner'); 
var roleBDroneA     = require('role.bdronea');
var roleBDroneB     = require('role.bdroneb');
var roleBZerg       = require('role.bzerg'); 
var roleBCarrier    = require('role.bcarrier');
var roleBLocust     = require('role.blocust'); 
var roleBLurker     = require('role.blurker');
var roleBSwarm      = require('role.bswarm');

// Associated Files - Mainframe3
var roleCDroneA     = require('role.cdronea');
var roleCDroneB     = require('role.cdroneb');

// Role Adjustment
var roleLurkerA     = require('role.lurkera'); 
var roleLurkerB     = require('role.lurkerb'); 
var roleQueen = require('role.queen'); 
var roleRunner = require('role.runner'); 
var roleZerg = require('role.zerg'); 
var roleSwarmA = require('role.swarma'); 
var roleRoach = require('role.roach'); 
var roleHiveA = require('role.hivea'); 
var roleHiveB = require('role.hiveb'); 
var roleHiveC = require('role.hivec'); 
var roleWorkerA = require('role.workera'); 
var roleWorkerB = require('role.workerb');
var roleHWorkerA = require('role.hworkera');
var roleHQueen = require('role.hqueen');
var roleHRunnerA = require('role.hrunnera');
var roleHLurkerA = require('role.hlurkera');


// Builds for Creeps
/* Queen  */ var numQ = 1; var bldQ = [CARRY,CARRY,MOVE,MOVE];
/* Runner */ var numY = 2; var bldY = [CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE];
/* Drone  */ var numR = 1; var bldR = [WORK,WORK,WORK,WORK,WORK,WORK,CARRY,MOVE];
/* Lurker */ var numL = 1; var bldL = [CARRY,MOVE,MOVE];
/* Zerg   */ var numZ = 4; var bldZ = [WORK,WORK,WORK,WORK,WORK,CARRY,MOVE];
/* Worker */ var numF = 1; var bldF = [WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE,MOVE]; 

/* Swarm  */ var numB = 1; var bldB = [WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE,MOVE];
/* Roach  */ var numX = 0; var bldX = [TOUGH,TOUGH,TOUGH,TOUGH,TOUGH,TOUGH,TOUGH,TOUGH,TOUGH,TOUGH,TOUGH,MOVE,MOVE,MOVE,MOVE,MOVE,ATTACK,ATTACK,ATTACK];
/* Carrier*/ var numC = 1; var bldC = [CARRY,CARRY,CARRY,CARRY,MOVE,MOVE]
/* Claim  */ var numH = 2;
/* Worker */ var numHW = 1; var bldHW = [WORK,CARRY,CARRY,MOVE,MOVE]
/* AMiner */ var numAM = 1; var bldAM = [WORK,CARRY,CARRY,MOVE,MOVE]

// Adjust Values
Memory.sourceMainframe  = '5bbcac919099fc012e635bb8';
Memory.sourceController = '5bbcac919099fc012e635bb6';
Memory.sourceMainframe2 = '5bbcac919099fc012e635bb4';
Memory.sourceController2 ='5bbcac919099fc012e635bb3';
Memory.depositId = '5f0af9e379f584174c194bcc'

var idSpire1='5effd7fcae5658ae41bacfa1'
var idSpire2='5f04ee7f797338d480cad65c'
var idSpire3='5f0850a600ea75396e7e619a'
var idSpire4='5f0ef84802e4899fa26bab4f';
var idspawn='Hive'

module.exports.loop = function () {



// Link
var linkMainframe = Game.getObjectById('5f04e726f64dca79fb489d7a');
var linkController = Game.getObjectById('5f04ebae90a41182e88db67c');
linkMainframe.transferEnergy(linkController, 200);

var linkMainframe2 = Game.getObjectById('5f0efaaf6dcc2dfcfabbac58');
var linkController2 = Game.getObjectById('5f0f0095ad5a492045309456');
linkMainframe2.transferEnergy(linkController2, 200);

// Mainframe1

    // Queen
        var aqueen = _.filter(Game.creeps, (creep) => creep.memory.role == 'aqueen');
        if(aqueen.length < numQ) {
        var newName = 'Queen' + Game.time;
        console.log('Spawning new AQueen: ' + newName);
        Game.spawns['Mainframe1'].spawnCreep(bldQ, newName, 
            {memory: {role: 'aqueen'}});        
        }
        
    // Runner
        var arunner = _.filter(Game.creeps, (creep) => creep.memory.role == 'arunner');
        if(arunner.length < numY && aqueen.length == numQ) {
        var newName = 'Runner' + Game.time;
        console.log('Spawning new ARunner: ' + newName);
        Game.spawns['Mainframe1'].spawnCreep(bldY, newName, 
            {memory: {role: 'arunner'}});        
        }
        
        // AMiner
        var aminer = _.filter(Game.creeps, (creep) => creep.memory.role == 'aminer');
        if(aminer.length < 0 && aqueen.length == numQ) {
        var newName = 'AMiner' + Game.time;
        console.log('Spawning new AMiner: ' + newName);
        Game.spawns['Mainframe1'].spawnCreep(bldAM, newName, 
            {memory: {role: 'aminer'}});        
        }
        
    // Zerg
        var azerg = _.filter(Game.creeps, (creep) => creep.memory.role == 'azerg');
        if(azerg.length < numZ && aqueen.length == numQ) {
        var newName = 'Zerg' + Game.time;
        console.log('Spawning new AZerg: ' + newName);
        Game.spawns['Mainframe1'].spawnCreep(bldZ, newName, 
            {memory: {role: 'azerg'}});        
        }
        
    // Carrier
        var acarrier = _.filter(Game.creeps, (creep) => creep.memory.role == 'acarrier');
        if(acarrier.length < numC && aqueen.length == numQ) {
        var newName = 'Carrier' + Game.time;
        console.log('Spawning new ACarrier: ' + newName);
        Game.spawns['Mainframe1'].spawnCreep(bldC, newName, 
            {memory: {role: 'acarrier'}});        
        }
    
    // Independent Drones
        var adronea = _.filter(Game.creeps, (creep) => creep.memory.role == 'adronea');
        if(adronea.length < numR && aqueen.length == numQ) {
        var newName = 'Drone' + Game.time;
        console.log('Spawning new ADroneA: ' + newName);
        Game.spawns['Mainframe1'].spawnCreep(bldR, newName, 
            {memory: {role: 'adronea'}});        
        }
        var adroneb = _.filter(Game.creeps, (creep) => creep.memory.role == 'adroneb');
        if(adroneb.length < numR && aqueen.length == numQ) {
        var newName = 'Drone' + Game.time;
        console.log('Spawning new ADroneB: ' + newName);
        Game.spawns['Mainframe1'].spawnCreep(bldR, newName, 
            {memory: {role: 'adroneb'}});        
        }
        
   //  Locust
        var alocust = _.filter(Game.creeps, (creep) => creep.memory.role == 'alocust');
        if(alocust.length < numL && aqueen.length == numQ) {
        var newName = 'Locust' + Game.time;
        console.log('Spawning new ALocust: ' + newName);
        Game.spawns['Mainframe1'].spawnCreep(bldL, newName, 
            {memory: {role: 'alocust'}});        
        }

    // Lurkers
        var alurker = _.filter(Game.creeps, (creep) => creep.memory.role == 'alurker');
        if(alurker.length < numL && aqueen.length == numQ) {
        var newName = 'Lurker' + Game.time;
        console.log('Spawning new ALurker: ' + newName);
        Game.spawns['Mainframe1'].spawnCreep(bldL, newName, 
            {memory: {role: 'alurker'}});        
        }
    
    // Independent Swarmer
        var aswarm = _.filter(Game.creeps, (creep) => creep.memory.role == 'aswarm');
        if(aswarm.length < 0 && aqueen.length == numQ) {
        var newName = 'Swarm' + Game.time;
        console.log('Spawning new ASwarmer: ' + newName);
        Game.spawns['Mainframe1'].spawnCreep(bldB, newName, 
            {memory: {role: 'aswarm'}});        
        }
        
    // Independent Miner
        var aminer = _.filter(Game.creeps, (creep) => creep.memory.role == 'aminer');
        if(aminer.length < 0 && aqueen.length == numQ) {
        var newName = 'Miner' + Game.time;
        console.log('Spawning new AMiner: ' + newName);
        Game.spawns['Mainframe1'].spawnCreep(bldB, newName, 
            {memory: {role: 'aminer'}});        
        }
        
// Mainframe2
    // Queen
        var bqueen = _.filter(Game.creeps, (creep) => creep.memory.role == 'bqueen');
        if(bqueen.length < 2) {
        var newName = 'Queen' + Game.time;
        console.log('Spawning new BQueen: ' + newName);
        Game.spawns['Mainframe2'].spawnCreep(bldQ, newName, 
            {memory: {role: 'bqueen'}});        
        }
        
    // Runner
        var brunner = _.filter(Game.creeps, (creep) => creep.memory.role == 'brunner');
        if(brunner.length < 4 && bqueen.length >= 1) {
        var newName = 'Runner' + Game.time;
        console.log('Spawning new BRunner: ' + newName);
        Game.spawns['Mainframe2'].spawnCreep(bldY, newName, 
            {memory: {role: 'brunner'}});        
        }
        
    // Zerg
        var bzerg = _.filter(Game.creeps, (creep) => creep.memory.role == 'bzerg');
        if(bzerg.length < 2 && bqueen.length >= 1) {
        var newName = 'Zerg' + Game.time;
        console.log('Spawning new BZerg: ' + newName);
        Game.spawns['Mainframe2'].spawnCreep([WORK,WORK,WORK,WORK,WORK,CARRY,MOVE], newName, 
            {memory: {role: 'bzerg'}});        
        }
        
    // Carrier
        var bcarrier = _.filter(Game.creeps, (creep) => creep.memory.role == 'bcarrier');
        if(bcarrier.length < 1 && bqueen.length >= 1) {
        var newName = 'Carrier' + Game.time;
        console.log('Spawning new BCarrier: ' + newName);
        Game.spawns['Mainframe2'].spawnCreep(bldC, newName, 
            {memory: {role: 'bcarrier'}});        
        }
        
   //  Locust
        var blocust = _.filter(Game.creeps, (creep) => creep.memory.role == 'blocust');
        if(blocust.length < numL && bqueen.length >= 1) {
        var newName = 'Locust' + Game.time;
        console.log('Spawning new BLocust: ' + newName);
        Game.spawns['Mainframe2'].spawnCreep([CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE], newName, 
            {memory: {role: 'blocust'}});        
        }

    // Lurkers
        var blurker = _.filter(Game.creeps, (creep) => creep.memory.role == 'blurker');
        if(blurker.length < 1 && bqueen.length >= 1) {
        var newName = 'Lurker' + Game.time;
        console.log('Spawning new BLurker: ' + newName);
        Game.spawns['Mainframe2'].spawnCreep(bldL, newName, 
            {memory: {role: 'blurker'}});        
        }  
        
    // Independent Swarmer
        var bswarm = _.filter(Game.creeps, (creep) => creep.memory.role == 'bswarm');
        if(bswarm.length < 0 && bqueen.length >= 1) {
        var newName = 'Swarm' + Game.time;
        console.log('Spawning new BSwarmer: ' + newName);
        Game.spawns['Mainframe2'].spawnCreep(bldB, newName, 
            {memory: {role: 'bswarm'}});        
        } 

    // Independent Drones
        var bdronea = _.filter(Game.creeps, (creep) => creep.memory.role == 'bdronea');
        if(bdronea.length < numR && bqueen.length >= 1) {
        var newName = 'Drone' + Game.time;
        console.log('Spawning new BDroneA: ' + newName);
        Game.spawns['Mainframe2'].spawnCreep(bldR, newName, 
            {memory: {role: 'bdronea'}});        
        }
        var bdroneb = _.filter(Game.creeps, (creep) => creep.memory.role == 'bdroneb');
        if(bdroneb.length < numR && bqueen.length >= 1) {
        var newName = 'Drone' + Game.time;
        console.log('Spawning new BDroneB: ' + newName);
        Game.spawns['Mainframe2'].spawnCreep(bldR, newName, 
            {memory: {role: 'bdroneb'}});        
        }    
        
// Mainframe3
        var cdronea = _.filter(Game.creeps, (creep) => creep.memory.role == 'cdronea');
        if(cdronea.length < 2 && bqueen.length >= 1) {
        var newName = 'Drone' + Game.time;
        console.log('Spawning new CDroneA: ' + newName);
        Game.spawns['Mainframe2'].spawnCreep([WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE], newName, 
            {memory: {role: 'cdronea'}});        
        }
        var cdroneb = _.filter(Game.creeps, (creep) => creep.memory.role == 'cdroneb');
        if(cdroneb.length < 2 && bqueen.length >= 1) {
        var newName = 'Drone' + Game.time;
        console.log('Spawning new CDroneB: ' + newName);
        Game.spawns['Mainframe2'].spawnCreep([WORK,WORK,WORK,CARRY,CARRY,CARRY,CARRY,MOVE,MOVE,MOVE,MOVE], newName, 
            {memory: {role: 'cdroneb'}});        
        }
    
// Melee/Roach
    var roach = _.filter(Game.creeps, (creep) => creep.memory.role == 'roach');
    if(roach.length < 0 && (dronea.length > 0 && droneb.length > 0)) {
    var newName = 'Roach' + Game.time;
    console.log('Spawning new Roach: ' + newName);
    Game.spawns['Mainframe2'].spawnCreep(bldX, newName, 
       {memory: {role: 'roach'}});        
    }



    
// Alt Worker
    var workera = _.filter(Game.creeps, (creep) => creep.memory.role == 'workera');
    if(workera.length < 0) {
    var newName = 'WorkerA' + Game.time;
    console.log('Spawning new WorkerA: ' + newName);
    Game.spawns['Mainframe1'].spawnCreep(bldF, newName, 
        {memory: {role: 'workera'}});        
    }
    var workerb = _.filter(Game.creeps, (creep) => creep.memory.role == 'workerb');
    if(workerb.length < 0) {
    var newName = 'WorkerB' + Game.time;
    console.log('Spawning new WorkerB: ' + newName);
    Game.spawns['Mainframe1'].spawnCreep(bldF, newName, 
        {memory: {role: 'workerb'}});        
    }

    var hqueen = _.filter(Game.creeps, (creep) => creep.memory.role == 'hqueen');
    if(hqueen.length < 0) {
    var newName = 'HQueen' + Game.time;
    console.log('Spawning new HQueen: ' + newName);
    Game.spawns['Mainframe2'].spawnCreep(bldQ, newName, 
        {memory: {role: 'hqueen'}}); 
    }
        
    var hworkera = _.filter(Game.creeps, (creep) => creep.memory.role == 'hworkera');
    if(hworkera.length < 0 && hqueen.length == 0) {
    var newName = 'HWorkerA' + Game.time;
    console.log('Spawning new HWorkerA: ' + newName);
    Game.spawns['Mainframe2'].spawnCreep(bldHW, newName, 
        {memory: {role: 'hworkera'}}); 
    }

    var hlurkera = _.filter(Game.creeps, (creep) => creep.memory.role == 'hlurkera');
    if(hlurkera.length < 0 && bqueen.length == numQ) {
    var newName = 'HLurkerA' + Game.time;
    console.log('Spawning new HLurkerA: ' + newName);
    Game.spawns['Mainframe2'].spawnCreep([CARRY,CARRY,CARRY,CARRY,MOVE,MOVE], newName, 
        {memory: {role: 'hlurkera'}});        
    }
// Spawn Capture
    var hivea = _.filter(Game.creeps, (creep) => creep.memory.role == 'hivea');
    if(hivea.length < 0 && bqueen.length == numQ) {
   var newName = 'HiveA' + Game.time;
    console.log('Spawning new HiveA: ' + newName);
    Game.spawns['Mainframe2'].spawnCreep([MOVE,MOVE,CLAIM], newName, 
        {memory: {role: 'hivea'}});        
    }
    var hiveb = _.filter(Game.creeps, (creep) => creep.memory.role == 'hiveb');
    if(hiveb.length < 0 && bqueen.length == numQ) {
    var newName = 'HiveB' + Game.time;
    console.log('Spawning new HiveB: ' + newName);
    Game.spawns['Mainframe1'].spawnCreep([WORK,WORK,CARRY,CARRY,MOVE,MOVE], newName, 
        {memory: {role: 'hiveb'}});        
    }
    var hivec = _.filter(Game.creeps, (creep) => creep.memory.role == 'hivec');
    if(hivec.length < 0 && bqueen.length == numQ) {
    var newName = 'HiveC' + Game.time;
    console.log('Spawning new HiveC: ' + newName);
    Game.spawns['Mainframe1'].spawnCreep([WORK,WORK,CARRY,CARRY,MOVE,MOVE], newName, 
        {memory: {role: 'hivec'}});        
    }


// Tower1 
    var spire1 = Game.getObjectById(idSpire1);
        if(spire1) { 
            var closestDamagedStructure = spire1.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (structure) => 
                ((structure.structureType == STRUCTURE_WALL || structure.structureType == STRUCTURE_RAMPART) && structure.hits < 250000) ||
                ((structure.structureType == STRUCTURE_ROAD) && structure.hits < 2500) ||
                ((structure.structureType == STRUCTURE_ROAD && structure.hits > 10000) && structure.hits < structure.hitsMax) ||
                ((structure.structureType == STRUCTURE_CONTAINER) && structure.hits < 150000)
            });
        
            if(closestDamagedStructure) {
            spire1.repair(closestDamagedStructure);
            };
  
            var closestHostile = spire1.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
            if(closestHostile) {
                spire1.attack(closestHostile);
            }
            
        }
        
// Tower2 
    var spire2 = Game.getObjectById(idSpire2);
        if(spire2) { 
            var closestHostile = spire2.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
            if(closestHostile) {
                spire2.attack(closestHostile);
            }
            var closestDamagedStructure = spire2.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (structure) => 
                ((structure.structureType == STRUCTURE_WALL || structure.structureType == STRUCTURE_RAMPART) && structure.hits < 150000) ||
                ((structure.structureType == STRUCTURE_ROAD) && structure.hits < 3000) ||
                ((structure.structureType == STRUCTURE_ROAD && structure.hits > 160000) && structure.hits < 175000) ||
                ((structure.structureType == STRUCTURE_CONTAINER) && structure.hits < 100000)
            });
            if(closestDamagedStructure) {
            spire2.repair(closestDamagedStructure);
            };
        }
        
// Tower3 
    var spire3 = Game.getObjectById(idSpire3);
        if(spire3) { 
            var closestHostile = spire3.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
            if(closestHostile) {
                spire3.attack(closestHostile);
            }
            var closestDamagedStructure = spire3.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (structure) => 
                ((structure.structureType == STRUCTURE_WALL || structure.structureType == STRUCTURE_RAMPART) && structure.hits < 50000) ||
                ((structure.structureType == STRUCTURE_ROAD) && structure.hits < 3000) ||
                ((structure.structureType == STRUCTURE_ROAD && structure.hits > 160000) && structure.hits < 175000) ||
                ((structure.structureType == STRUCTURE_CONTAINER) && structure.hits < 100000)
            });
            if(closestDamagedStructure) {
            spire3.repair(closestDamagedStructure);
            };
        }
        
// Tower4 
    var spire4 = Game.getObjectById(idSpire4);
        if(spire4) { 
            var closestDamagedStructure = spire4.pos.findClosestByRange(FIND_STRUCTURES, {
            filter: (structure) => 
                ((structure.structureType == STRUCTURE_WALL || structure.structureType == STRUCTURE_RAMPART) && structure.hits < 40000) ||
                ((structure.structureType == STRUCTURE_ROAD) && structure.hits < 2500) ||
                ((structure.structureType == STRUCTURE_ROAD && structure.hits > 10000) && structure.hits < structure.hitsMax) ||
                ((structure.structureType == STRUCTURE_CONTAINER) && structure.hits < 100000)
            });
        
            if(closestDamagedStructure) {
            spire4.repair(closestDamagedStructure);
            };
  
            var closestHostile = spire4.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
            if(closestHostile) {
                spire4.attack(closestHostile);
            }
            
        }
        
// AutoSpawn
    if(Game.spawns['Mainframe1'].spawning) { 
        var spawningCreep = Game.creeps[Game.spawns['Mainframe1'].spawning.name];
        Game.spawns['Mainframe1'].room.visual.text(
            '🛠️' + spawningCreep.memory.role,
            Game.spawns['Mainframe1'].pos.x + 1, 
            Game.spawns['Mainframe1'].pos.y, 
            {align: 'left', opacity: 0.8});
    }

// Clear creep memory
    for(var name in Memory.creeps) {
        if(!Game.creeps[name]) {
            delete Memory.creeps[name];
            console.log('Clearing non-existing creep memory:', name);
        }
    }

// Roles run
    for(var name in Game.creeps) {
        var creep = Game.creeps[name];
        	if(!Game.creeps[name]) {
				delete Memory.creeps[name];
			}
        if(creep.memory.role == 'queen') {
            roleQueen.run(creep);
        }
        if(creep.memory.role == 'lurkera') {
            roleLurkerA.run(creep);
        }
        if(creep.memory.role == 'lurkerb') {
            roleLurkerB.run(creep);
        }
         if(creep.memory.role == 'zerg') {
            roleZerg.run(creep);
        }
         if(creep.memory.role == 'swarma') {
            roleSwarmA.run(creep);
        }
         if(creep.memory.role == 'runner') {
            roleRunner.run(creep);
        }
         if(creep.memory.role == 'workera') {
            roleWorkerA.run(creep);
        }
         if(creep.memory.role == 'workerb') {
            roleWorkerB.run(creep);
        }
         if(creep.memory.role == 'acarrier') {
            roleACarrier.run(creep);
        }
         if(creep.memory.role == 'hivea') {
            roleHiveA.run(creep);
        }
         if(creep.memory.role == 'hiveb') {
            roleHiveB.run(creep);
        }
         if(creep.memory.role == 'hivec') {
            roleHiveC.run(creep);
        }
         if(creep.memory.role == 'hworkera') {
            roleHWorkerA.run(creep);
        }
         if(creep.memory.role == 'hqueen') {
            roleHQueen.run(creep);
        }
         if(creep.memory.role == 'brunner') {
            roleBRunner.run(creep);
        }
         if(creep.memory.role == 'hlurkera') {
            roleHLurkerA.run(creep);
        }
         if(creep.memory.role == 'bcarrier') {
            roleBCarrier.run(creep);
        }
         if(creep.memory.role == 'alocust') {
            roleALocust.run(creep);
        }
         if(creep.memory.role == 'blocust') {
            roleBLocust.run(creep);
        }
         if(creep.memory.role == 'azerg') {
            roleAZerg.run(creep);
        }
         if(creep.memory.role == 'bzerg') {
            roleBZerg.run(creep);
        }
         if(creep.memory.role == 'alurker') {
            roleALurker.run(creep);
        }
         if(creep.memory.role == 'blurker') {
            roleBLurker.run(creep);
        }
         if(creep.memory.role == 'aqueen') {
            roleAQueen.run(creep);
        }
         if(creep.memory.role == 'bqueen') {
            roleBQueen.run(creep);
        }
         if(creep.memory.role == 'arunner') {
            roleARunner.run(creep);
        }
         if(creep.memory.role == 'adronea') {
            roleADroneA.run(creep);
        }
         if(creep.memory.role == 'bdronea') {
            roleBDroneA.run(creep);
        }
         if(creep.memory.role == 'adroneb') {
            roleADroneB.run(creep);
        }
         if(creep.memory.role == 'bdroneb') {
            roleBDroneB.run(creep);
        }
         if(creep.memory.role == 'aswarm') {
            roleASwarm.run(creep);
        }
         if(creep.memory.role == 'bswarm') {
            roleBSwarm.run(creep);
        }
         if(creep.memory.role == 'cdronea') {
            roleCDroneA.run(creep);
        }
         if(creep.memory.role == 'cdroneb') {
            roleCDroneB.run(creep);
        }
         if(creep.memory.role == 'aminer') {
            roleAMiner.run(creep);
        }
    }
};
