var roleBRunner = {

    run: function(creep) {
        
        if (creep.memory.pull && creep.carry.energy == 0) {
            creep.memory.pull = false;
            creep.say('🐻');
        }
        if (!creep.memory.pull && creep.carry.energy == creep.carryCapacity) {
            creep.memory.pull = true;
            creep.say('🐻');
        }
        
        if (creep.memory.pull) {
            var containers = creep.room.find(FIND_STRUCTURES, {
                filter: (structure) => {
                    return (structure.structureType == STRUCTURE_STORAGE) && 
                        (structure.store[RESOURCE_ENERGY] >= 0);
                }
            });
            var source = creep.pos.findClosestByPath(containers);
            if (source) {
                if(creep.transfer(source, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(source), {visualizePathStyle: {stroke: '#DCBFF5'}};
                }
            }
        }
        
        else {
            var containers = creep.room.find(FIND_STRUCTURES, {
                filter: (structure) => {
                    return (structure.structureType == STRUCTURE_CONTAINER) && 
                        (structure.store[RESOURCE_ENERGY] > 100);
                }
            });
            var source = creep.pos.findClosestByPath(containers);
            if (source) {
                if(creep.withdraw(source, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(source), {visualizePathStyle: {stroke: '#DCBFF5'}};
                }
            }
        }
    }
};

module.exports = roleBRunner;
